import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController _textController = TextEditingController();

  List<ChatMessage> _chatMessages = [];

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    // Add default bot messages to the chat messages list
    ChatMessage botMessage1 = ChatMessage(
      text: 'Hi there! How can I assist you today?',
      isUserMessage: false,
    );
    ChatMessage botMessage2 = ChatMessage(
      text: 'You can ask me anything related to immigration.',
      isUserMessage: false,
    );

    setState(() {
      _chatMessages.insert(0, botMessage2);
      _chatMessages.insert(0, botMessage1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 16.0),
              child: Image.asset(
                "assets/images/chatbot_icon.jpeg",
                width: 40,
                height: 40,
              ),
            ),
            const SizedBox(width: 16.0),
            Text('ImmiGPT'),
          ],
        ),
        backgroundColor: Color(0xFF0B4374),
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => [
              PopupMenuItem(
                child: Text('User Profile'),
              ),
              PopupMenuItem(
                child: Text('Settings'),
              ),
              PopupMenuItem(
                child: Text('Logout'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _chatMessages.length,
              itemBuilder: (BuildContext context, int index) {
                return _buildChatMessage(_chatMessages[index]);
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: _textController,
                    decoration: InputDecoration(
                      hintText: 'Type your message here',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: _handleSubmitted,
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  _handleSubmitted(_textController.text);
                },
                icon: Icon(Icons.send),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _handleSubmitted(String text) {
    if (text.isEmpty) {
      return;
    }

    // Add user message to the chat messages list
    ChatMessage userMessage = ChatMessage(text: text, isUserMessage: true);
    setState(() {
      _chatMessages.insert(0, userMessage);
    });

    // TODO: Add logic to handle chatbot response.
    // For now, we'll just add a default response
    ChatMessage chatbotMessage;

    if (text.toLowerCase().contains('hi') ||
        text.toLowerCase().contains('hello') ||
        text.toLowerCase().contains('hey')) {
      chatbotMessage = ChatMessage(
        text: 'Hi there, how can I assist you today?',
        isUserMessage: false,
      );
    } else if (text.toLowerCase().contains('help')) {
      chatbotMessage = ChatMessage(
        text: 'Sure, I can help you with that. What do you need help with?',
        isUserMessage: false,
      );
    } else {
      chatbotMessage = ChatMessage(
        text: 'I didn\'t understand what you said. Can you please rephrase?',
        isUserMessage: false,
      );
    }

    setState(() {
      _chatMessages.insert(0, chatbotMessage);
    });

    _textController.clear();
  }

  Widget _buildChatMessage(ChatMessage message) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Align(
        alignment:
            message.isUserMessage ? Alignment.topRight : Alignment.topLeft,
        child: Container(
          decoration: BoxDecoration(
            color: message.isUserMessage ? Colors.blue[100] : Colors.grey[200],
            borderRadius: BorderRadius.circular(16.0),
          ),
          padding: const EdgeInsets.all(16.0),
          child: GestureDetector(
            onTap: () {
              if (!message.isUserMessage) {
                setState(() {
                  _textController.text = message.text;
                });
              }
            },
            child: Text(message.text),
          ),
        ),
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUserMessage;

  ChatMessage({required this.text, required this.isUserMessage});
}
